# Final Demo Script (about 5 minutes)

1. **(0:00–0:30) Problem.** "Students lose tasks and notes across apps. My project asks how AI can help build a system a student keeps using."
2. **(0:30–1:30) Notion.** Show Goals, Tasks board, and the Weekly Review page. Create one live task.
3. **(1:30–2:30) Obsidian.** Open the vault. Show the DBMS index, click a link, show the graph view.
4. **(2:30–3:15) Automation.** Show the Zap or the manual run. Read one line of the generated summary.
5. **(3:15–4:00) Results.** Show 3 numbers from the trial log and one before/after change.
6. **(4:00–4:45) Honesty.** Show one AI error from the verification report and how you caught it. Explain the privacy rule.
7. **(4:45–5:00) Close.** One thing you would change next time.

Practice this twice before the demo, and keep your real numbers on screen.
