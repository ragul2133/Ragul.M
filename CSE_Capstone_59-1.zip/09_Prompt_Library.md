# Prompt Library (Task 11)

Each prompt has a purpose, a template, and a note on how to check the output.

## 1. Summarize lecture notes
**Purpose:** turn messy notes into a short summary.
```
Summarize the notes below in 5 bullet points. Use only information in the notes. If something is unclear, write "unclear" instead of guessing.

Notes:
[paste notes]
```
**Check:** compare each bullet with the original notes.

## 2. Make quiz questions
```
Create 5 multiple-choice questions from the text below. Give 4 options each, mark the correct answer, and explain it in one sentence.

Text:
[paste text]
```
**Check:** confirm the answer is in the text.

## 3. Plan a week of tasks
```
My tasks this week are below with due dates and estimated minutes. Create a day-by-day plan, Monday to Friday, with no more than 3 hours of study per day. Flag any task that cannot fit.

Tasks:
[paste]
```
**Check:** total minutes per day match the estimates.

## 4. Weekly review
Use the prompt in 08_Automation_Weekly_Review.md.

## 5. Explain a concept at my level
```
Explain [concept] to a second-year CSE student. Use one example from databases or operating systems. Keep it under 150 words.
```
**Check:** verify the definition against your textbook or lecture slides.

## 6. Rewrite a note in my own words
```
Rewrite the text below in simpler words. Keep all facts unchanged. Do not add new facts.

Text:
[paste]
```
**Check:** no fact was added or removed.

## Privacy rule
Do not paste private information (passwords, personal messages, health details, or other people's data) into any AI prompt.
