# Ethics Statement (Task 12)

## What I keep out of AI prompts
- Passwords, account numbers, and personal identifiers
- Private journal entries and personal health or relationship details
- Other people's messages or information

## What I did
- Used only the notes I chose to share with AI tools, and kept sensitive notes in Obsidian on my own device.
- Checked AI outputs before using them (see 10_Verification_Report.md).

## What the system did NOT do (report honestly)
Fill this in from your trial. Examples to check:
- Did any AI tool store or use my prompts? (Read the tool's privacy policy and write what it says.)
- Did any output contain an error I missed at first?
- Did any automation fail or send data to the wrong place?

Result: ____
