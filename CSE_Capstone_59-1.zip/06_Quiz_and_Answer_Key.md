# 10-Question Quiz with Answer Key (Task 8)

## Questions

1. What are the four buckets of the PARA method?
2. What is the main idea of a Zettelkasten note?
3. In Notion, which property type links a task to a goal?
4. What is the difference between a database view and a database in Notion?
5. What does `[[Note Name]]` do in Obsidian?
6. What does "Atomic" mean in ACID?
7. Name the first three normal forms in order.
8. Name two scheduling algorithms and one trade-off of each.
9. What are the four necessary conditions for deadlock?
10. Why should AI outputs be verified before use?

## Answer Key

1. Projects, Areas, Resources, Archives.
2. One idea per note, linked to other notes so knowledge connects.
3. Relation.
4. A database holds the data; a view is a filtered or sorted way of showing the same data.
5. Creates an internal link to the note with that name.
6. A transaction completes fully or not at all.
7. 1NF, 2NF, 3NF.
8. Example: Round Robin (fair, but more context switches); FCFS (simple, but long waits for short jobs). Any valid pair with a correct trade-off earns full marks.
9. Mutual exclusion, hold and wait, no preemption, circular wait.
10. AI can hallucinate facts, give outdated information, or give unsafe advice.
