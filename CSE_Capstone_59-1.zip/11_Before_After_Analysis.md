# Before / After Analysis

Fill this in with your own data from the trial (05_Trial_Log.md).

| Measure | Before the system | After 2 weeks | Change |
|---|---|---|---|
| Tasks missed per week | ____ | ____ | ____ |
| Minutes spent looking for notes per day | ____ | ____ | ____ |
| Times I forgot a deadline | ____ | ____ | ____ |
| Study sessions planned vs completed | ____ | ____ | ____ |

## What changed
Describe one concrete change you noticed, with a date from your trial log.

## What did not change
Describe one thing that stayed the same or got worse.

## Honest conclusion
Was the system worth the effort? Answer with your data, not with guesses.
