---
subject:
tags:
created: {{date}}
---

# {{title}}

## Summary (in my own words)


## Key points
-

## Related
- [[ ]]

## Source
-

Subject index: [[Index]]
