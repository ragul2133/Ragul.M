# Indexing

An index is a separate structure that speeds up lookups on a column at the cost of extra storage and slower writes.

- B-tree indexes suit range queries.
- Hash indexes suit exact-match lookups.

Related: [[Normalization]], [[ACID Properties]].

Subject index: [[Index]]

#dbms #indexing
