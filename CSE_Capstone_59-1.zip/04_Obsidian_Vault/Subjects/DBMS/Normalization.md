# Normalization

Normalization organizes tables to reduce redundancy and update anomalies.

- 1NF: atomic values, no repeating groups.
- 2NF: 1NF and no partial dependency on a composite key.
- 3NF: 2NF and no transitive dependency.

Related: [[ACID Properties]] (transactions keep data consistent), [[Indexing]].

Subject index: [[Index]]

#dbms #normalization
