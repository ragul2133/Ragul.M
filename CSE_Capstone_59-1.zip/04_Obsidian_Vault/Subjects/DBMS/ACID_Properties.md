# ACID Properties

- **Atomicity:** a transaction completes fully or not at all.
- **Consistency:** a transaction moves the database from one valid state to another.
- **Isolation:** concurrent transactions do not interfere in visible ways.
- **Durability:** committed changes survive crashes.

Related: [[Normalization]], [[Indexing]].

Subject index: [[Index]]

#dbms #transactions
