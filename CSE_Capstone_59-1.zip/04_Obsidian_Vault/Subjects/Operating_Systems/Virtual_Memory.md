# Virtual Memory

Virtual memory gives each process its own address space; the OS maps pages to physical memory and swaps pages to disk when needed.

- Page faults load missing pages.
- Page replacement (e.g. LRU) chooses which page to evict.

Related: [[Process Scheduling]].

Subject index: [[Index]]

#os #memory
