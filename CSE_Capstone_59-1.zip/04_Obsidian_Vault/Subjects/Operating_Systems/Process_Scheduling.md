# Process Scheduling

The OS decides which ready process runs on the CPU next.

- FCFS: simple, can cause long waits.
- Round Robin: each process gets a fixed time slice.
- Shortest Job First: lowers average wait, needs time estimates.

Related: [[Deadlock]], [[Virtual Memory]].

Subject index: [[Index]]

#os #scheduling
