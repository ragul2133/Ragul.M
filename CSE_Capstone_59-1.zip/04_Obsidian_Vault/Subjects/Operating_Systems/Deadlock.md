# Deadlock

A deadlock occurs when processes wait forever for resources held by each other.

Four necessary conditions: mutual exclusion, hold and wait, no preemption, circular wait. Breaking any one prevents deadlock.

Related: [[Process Scheduling]].

Subject index: [[Index]]

#os #deadlock
