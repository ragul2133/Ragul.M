# 2-Week Trial Log (Task 7)

Fill this in with REAL data from your own use. Leave blanks if you didn't do something.

**Start date:** ____  **End date:** ____

| Day | Date | Tasks planned | Tasks done | Minutes spent in system | Minutes saved (est.) | Problems / notes |
|---|---|---|---|---|---|---|
| 1 | | | | | | |
| 2 | | | | | | |
| 3 | | | | | | |
| 4 | | | | | | |
| 5 | | | | | | |
| 6 | | | | | | |
| 7 | | | | | | |
| 8 | | | | | | |
| 9 | | | | | | |
| 10 | | | | | | |
| 11 | | | | | | |
| 12 | | | | | | |
| 13 | | | | | | |
| 14 | | | | | | |

## Summary (fill after day 14)
- Days used: ____ / 14
- Total minutes in system: ____
- Estimated minutes saved: ____
- Top 3 problems:
  1.
  2.
  3.
