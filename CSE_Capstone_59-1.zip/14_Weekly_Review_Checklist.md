# Weekly Review Checklist

Do this every Sunday (about 20 minutes).

- [ ] Clear the Inbox in the Tasks database (every task has a due date and goal)
- [ ] Mark finished tasks as Done
- [ ] Move unfinished tasks to next week, or drop them with a reason
- [ ] Check each Goal's progress; update the number
- [ ] Add 3 new notes to Obsidian from this week's lectures, linked to a subject index
- [ ] Read the AI weekly summary; correct anything that is wrong
- [ ] Write one line: what worked this week, what didn't
- [ ] Choose the 3 most important tasks for next week

Weekly review template (paste into Notion "Weekly Review" page):
```
Week of: ____
Done: ____
Carried over: ____
What worked: ____
What didn't: ____
Top 3 next week: 1. ___ 2. ___ 3. ___
```
